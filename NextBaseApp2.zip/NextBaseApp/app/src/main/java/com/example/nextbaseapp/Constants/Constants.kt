package com.example.nextbaseapp.Constants

object Constants {

    const val BASE_URL = "https://us-central1-mynextbase-connect.cloudfunctions.net/"
    const val RESPONSE_TAG = "Data_RESPONSE"
    const val xAcc_string =  "xAcc"
    const val yAcc_string =  "yAcc"
    const val zAcc_string =  "zAcc"

}