package com.example.nextbaseapp.view.fragment


import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.nextbaseapp.ChartView.MainActivity
import com.facebook.testing.screenshot.Screenshot
import org.junit.Test
import org.junit.runner.RunWith


@RunWith(AndroidJUnit4::class)
class ViewTest : Screenshot() {

    val activity = ActivityScenario.launch(MainActivity::class.java)


    @Test
    fun ChartViewSnapshot() {
        val activity = MainActivity()
        TakeScreenshot(activity)
    }


    fun TakeScreenshot(activity: Activity) {
        Screenshot.snapActivity(activity).record()
    }


    fun startActivity(args: Bundle = Bundle()): T {
        val intent = Intent()
        intent.putExtras(args)
        return testRule.launchActivity(intent)
    }


}